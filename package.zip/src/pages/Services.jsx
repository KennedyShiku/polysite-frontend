import ServicesComponent from '../components/Services';

const Services = () => {
  return <ServicesComponent />;
};

export default Services;
