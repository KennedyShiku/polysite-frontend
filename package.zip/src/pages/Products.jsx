import ProductsComponent from '../components/Products'

const Products = () => {
  return <ProductsComponent />;
}

export default Products