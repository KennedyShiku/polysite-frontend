import QueriesComponent from '../components/Queries';

const Queries = () => {
  return <QueriesComponent />;
};

export default Queries;
