import ReviewsComponent from '../components/Reviews'

const Reviews = () => {
  return <ReviewsComponent />;
}

export default Reviews