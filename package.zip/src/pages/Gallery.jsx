import GalleryComponent from '../components/Gallery'

const Gallery = () => {
  return <GalleryComponent />;
}

export default Gallery